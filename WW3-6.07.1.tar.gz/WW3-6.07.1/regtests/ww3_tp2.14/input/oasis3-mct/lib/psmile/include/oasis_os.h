
#undef __NO_4BYTE_REALS

#ifdef __SXdbl4
#define __NO_4BYTE_REALS
#endif

#ifdef __crayx1
#define  __NO_4BYTE_REALS
#endif
